A ZIP archive that is not an Office package.
